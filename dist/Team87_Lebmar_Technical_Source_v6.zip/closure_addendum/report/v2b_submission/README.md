# V2b report (final, 9 pages)

Team Lebmar (87) — Chengxuan YUAN.

This directory contains the final 9-page A4, 11pt English report (`main.pdf`)
and its LaTeX source (`main.tex`). This is the version intended for CMT
upload as the main submission file.

## Compile

```sh
cd report/v2b_submission
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The two passes resolve the cross-references. The figures are generated from the
frozen final arrays by:

```sh
python scripts/make_v2b_report_figures.py
```

The one-page onboarding flow is a standalone LaTeX/TikZ page in
`figures/q1_onboarding_flow.tex`; the report includes its cropped PDF.

## Scope

The report uses the frozen V2b final results, the development 1–120 Q1 product
screen and the development-only B/E funding-gate addendum. It does not fit,
select or change a model. The final 121–180 sample was previously exposed and
is described as nonblind in the report itself.
