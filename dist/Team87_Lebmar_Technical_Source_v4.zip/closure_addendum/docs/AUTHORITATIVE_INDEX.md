**Package copy:** this is the v4 closure-addendum copy. It contains the report draft, Q1 product screen and selected current evidence; historical archive links point to the full repository.

# Authoritative document index

**Read this first when preparing the report or checking a number.** The project
contains multiple generations of evidence. Historical files remain valid at their
own timestamps; they are not all current. This index prevents using a superseded
V1/V2/earlier-final number in the final submission.

Last updated: 2026-10-19 (submission closure). Current branch:
`codex/risk-budget-development`.

## Current authoritative chain

| Purpose | Authoritative file |
| --- | --- |
| Locked V2b model, Q1 products/assignments, Q2 rule, final scope | [mitigation_main_model_registry.json](mitigation_main_model_registry.json) |
| Technical judgment, final rows and parameter meanings | [mitigation_technical_completion_judgment.json](mitigation_technical_completion_judgment.json) |
| Final 121–180 evaluation (14 objects, 60 paths) | [results/mitigation_locked_final_evaluation_v1/](../results/mitigation_locked_final_evaluation_v1/) |
| Independent final audit | [independent_audit.json](../results/mitigation_locked_final_evaluation_v1/independent_audit.json) |
| Isolated final replay | results/mitigation_locked_final_reproduction_v1/ (full repository) |
| Requirements/evidence closure | [technical_evidence_closure_2026_10_19.json](technical_evidence_closure_2026_10_19.json) |
| Last-mile diagnostics and verification | [technical_last_mile_completion_2026_10_19.json](technical_last_mile_completion_2026_10_19.json) |
| Task-facing answer sheet | [TASK_ANSWER_SHEET.md](../submission/TASK_ANSWER_SHEET.md) |
| Q1 5×3 product screen | [Q1_PRODUCT_COMPARISON.md](../submission/Q1_PRODUCT_COMPARISON.md) and [results/q1_product_comparison_v1/](../results/q1_product_comparison_v1/) |
| Q1 one-page onboarding flow | [Q1_ONBOARDING_FLOW.md](../submission/Q1_ONBOARDING_FLOW.md) |
| V2b report draft | [main.pdf](../report/v2b_submission/main.pdf) and [main.tex](../report/v2b_submission/main.tex) |
| Q3 sensitivity note | [Q3_SENSITIVITY.md](../submission/Q3_SENSITIVITY.md) |
| Compact final reproduction guide | [FINAL_REPRODUCTION.md](../submission/FINAL_REPRODUCTION.md) |
| Data provenance/licence | [DATA_NOTICE.md](DATA_NOTICE.md) |
| AI assistance record | [AI_USE.md](../submission/AI_USE.md) |

The final submission ZIP is [the enclosing v4 package README](../../README.md)
after the closure build. It keeps the V2 core unchanged and adds only the closure
documents (answer sheet, Q3 note, this index and a package README).

## Superseded or historical material — do not use for final claims

| Item | Status / reason |
| --- | --- |
| [current_model_contract_2026_10_19.json](current_model_contract_2026_10_19.json) | **Pre-final document.** Its Q1 targets/assignments are consistent, but its `current_C_service` says execution Review and its `freeze_and_delivery_boundary` says final 121–180 not read. Those fields predate the V2b final and are superseded by the registry/final evaluation above. |
| [main_model_registry.json](main_model_registry.json) | Older main-model registry; historical evidence only. |
| RESULTS_REVIEW.md (full repository) and VERIFICATION.md (full repository) | Archived V1 S2/R review and cached-result verification. Their old portfolios (e.g. Conservative 15/5/80) and E→Conservative assignment are **not** the current V2b products/assignments. |
| results/final_locked_evaluation_v1/ (full repository) and results/final_locked_analysis_v1/ (full repository) | Earlier-model final archive; retained, not the V2b final. |
| results/final_locked_checkpoint_v1/ (full repository) | Earlier checkpoint; historical. |
| report/ (full repository) and output/pdf/ (full repository) | Archived V1/S2+R prototype; not regenerated for V2b. Do not quote its 3.66%/43.44% numbers as the current result. |
| 44-word explanation in `current_model_contract` | Older general wording; the final Q2 customer text is the 41-word text in [mitigation_customer_explanation_contract.json](mitigation_customer_explanation_contract.json). |
| `main` branch before the closure update | It was 80 commits behind the current branch. The closure pushes the current tree to `main` so the GitHub homepage matches this index. |

## Number conventions

- Growth: net real annualised log growth; CAGR = exp(G) − 1.
- Large loss: maximum real drawdown from the complete original peak, annual
  endpoints; larger is worse. It does not observe intrayear highs/lows.
- P10/P90: empirical inverse CDF; median: ordinary median.
- Fees: nominal units per initial 100, not an annual percentage.
- Trade fraction: periods with actual destination moved >1e-12 divided by the
  original horizon; the current final V2b value is 382/1,800 = 21.22%, including
  the mandatory initial allocation. Excluding the initial allocation:
  322/1,740 = 18.51%. Ordinary autonomous service is 350/1,800 = 19.44% and is a
  different metric.
- Q1 static B/C/E references are annual product stresses, not the Q2 guarded
  service and not autonomous approvals. Their adverse tails (B 11/60, C 8/60,
  E 5/60 with P10 −1.58%) must remain visible.

## Frozen-evidence boundary

The historical producers, audits, checkpoints and result archives are **not to be
edited**. This closure adds new documents and a new package; it does not rewrite a
frozen manifest. If a historical checkpoint hashes an older README or file, that
checkpoint remains a true statement about its own timestamp, not about the current
tree. The closure verification in
results/submission_closure_v1/verification.json (full repository)
records the new files and checks.
