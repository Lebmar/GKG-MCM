# Team 87 — SafeInvest technical submission package (v3 closure)

Participant: **Chengxuan YUAN**. Team: **Lebmar (87)**.
2026 HKUST(GZ) MCM Senior Group Problem A.

This ZIP is the supplementary-material package. It is far below the CMT 50 MB
limit. It contains the unchanged compact V2 source plus a small closure addendum;
it does **not** contain the paper or the large historical result archive.

## What is inside

```
technical_source_v2/     unchanged V2 compact source (564 files), including
                         data/SafeInvest_Synthetic_Data.csv, the frozen kernels,
                         the final adapter and expected 14-object outputs
closure_addendum/        submission answer sheet, Q3 sensitivity note,
                         authoritative index, selected current evidence and
                         last-mile diagnostic scripts/docs
SHA256SUMS.txt           SHA-256 of every file in this package
README.md                this guide
```

The V2 core is byte-identical to `Team87_Lebmar_Technical_Source_v2.zip`
(SHA-256 `78b710d75f9cba9497ac6059995ac874dfa30a949b06a8072088235cd3f2d4dc`).
The closure addendum adds documents; it does not change the model or the frozen
final arrays.

## Reproduce the locked final tables

From this package root:

```sh
cd technical_source_v2
python -m pip install -r requirements-research-pinned.txt
python scripts/submission_final_adapter.py --reproduce-fixed-nonblind-final --output ../reproduction_final_v1
```

This reads training IDs 1–120 and evaluation IDs 121–180, reproduces all 14
locked objects (Q2 main + three references; Q1 A–E; Q1 equal-thirds references),
and checks every saved array field plus the ten table/JSON artifacts. It does not
fit, select, change a parameter or create a new validation sample. The command
refuses to overwrite an existing output; use a new `--output` path for a separate
intended run.

A constructed-data smoke run (no market CSV) is:

```sh
python scripts/submission_final_adapter.py --output ../reproduction_synthetic_v1
```

The final scenarios 121–180 were exposed earlier in the project. This is a
fixed-table, **nonblind** reproduction, not fresh blind validation. See
`closure_addendum/submission/FINAL_REPRODUCTION.md` and
`technical_source_v2/SUBMISSION_README.md` for the full contract.

## Closure documents

- `closure_addendum/submission/TASK_ANSWER_SHEET.md` — Q1/Q2/Q3 answers,
  definitions, exact numbers and evidence map.
- `closure_addendum/submission/Q3_SENSITIVITY.md` — fee/support/inflation
  sensitivity and the safeguard wording.
- `closure_addendum/docs/AUTHORITATIVE_INDEX.md` — current vs superseded
  documents. Read this before quoting an older report or registry.
- `closure_addendum/submission/LAST_MILE_DIAGNOSTICS.md` and
  `closure_addendum/scripts/` — the additive diagnostic source. The full replay
  needs the complete saved-input repository and is not standalone in this ZIP.

Links inside the addendum are package-relative for the selected current evidence
copied here. Historical archives (older final results, V1 report, large raw
replays) remain in the full repository and are not needed to reproduce the locked
final tables.

## Data, AI and licence

The supplied CSV is unmodified. The synthetic data and problem statement are
distributed for noncommercial use under CC BY-NC-SA 4.0; see
`closure_addendum/docs/DATA_NOTICE.md` and
`technical_source_v2/submission/LICENSE-DATA-CC-BY-NC-SA-4.0.txt`.
No new blanket open-source licence is granted to the participant's original code.
AI assistance and the participant's responsibility are recorded in
`closure_addendum/submission/AI_USE.md`.
