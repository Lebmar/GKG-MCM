# Team 87 - SafeInvest technical submission package (v5 closure)

Participant: Chengxuan YUAN. Team: Lebmar (87).
2026 HKUST(GZ) MCM Senior Group Problem A.

This ZIP is the CMT supplementary-material package (the report is uploaded
separately). It contains the unchanged compact V2 source, the closure addendum,
the Q1 5x3 comparison, the final 9-page V2b report, and the development-only
B/E funding-gate addendum. It is far below 50 MB.

## What is inside

~~~text
technical_source_v2/     unchanged V2 compact source (564 files), including data,
                         frozen kernels, final adapter and expected 14-object outputs
closure_addendum/        Q1 5x3 table, one-page onboarding flow, answer sheet,
                         Q3 sensitivity, final report source/PDF, the B/E
                         funding-gate addendum (protocol, freeze, audit, isolated
                         replay, focused tests), selected evidence and the
                         additive diagnostic scripts
SHA256SUMS.txt           SHA-256 of every file in this package
README.md                this guide
~~~

The V2 core is byte-identical to Team87_Lebmar_Technical_Source_v2.zip
(SHA-256 78b710d75f9cba9497ac6059995ac874dfa30a949b06a8072088235cd3f2d4dc).
The addendum does not change the model or the frozen final arrays.

## Reproduce the locked final tables

~~~sh
cd technical_source_v2
python -m pip install -r requirements-research-pinned.txt
python scripts/submission_final_adapter.py --reproduce-fixed-nonblind-final --output ../reproduction_final_v1
~~~

This reads training IDs 1-120 and evaluation IDs 121-180, reproduces all 14
locked objects, and checks every saved array field plus the ten table/JSON
artifacts. It does not fit, select, change a parameter or create a new validation
sample. The command refuses to overwrite an existing output. The final scenarios
were exposed earlier; this is fixed-table nonblind reproduction, not fresh blind
validation.

A constructed-data smoke run is:

~~~sh
python scripts/submission_final_adapter.py --output ../reproduction_synthetic_v1
~~~

## Q1, Q2 addendum and report

- closure_addendum/submission/Q1_PRODUCT_COMPARISON.md - 5x3 development and final
  product tables; the development screen is used for the frozen assignments.
- closure_addendum/submission/Q1_ONBOARDING_FLOW.md - one-page flow and A-E trace.
- closure_addendum/submission/Q1_GUARD_GENERALIZATION.md - development-only B/E
  funding-gate study: the unchanged locked V2b rule applied to profiles B and E
  declines automatic funding at inception (protocol, source freeze, independent
  audit with 10,993 checks, isolated replay with byte-exact artifact match and
  210 exact array fields, and focused unit tests are included alongside).
- closure_addendum/report/v2b_submission/main.pdf - final 9-page A4, 11pt English
  report; main.tex and figures are included for review.

The B/E addendum is a resubstitution diagnostic on development scenarios 1-120
only: no final scenarios were read, no parameters were fitted or selected, and
no locked artifact was modified.

Upload the report separately to CMT; this ZIP is the supplementary/source
package.

## Data, AI and licence

The supplied CSV is unmodified. The synthetic data and problem statement are
distributed for noncommercial use under CC BY-NC-SA 4.0; see
closure_addendum/docs/DATA_NOTICE.md and
technical_source_v2/submission/LICENSE-DATA-CC-BY-NC-SA-4.0.txt. No new blanket
open-source licence is granted to the participant's original code. AI assistance
and responsibility are recorded in closure_addendum/submission/AI_USE.md.
